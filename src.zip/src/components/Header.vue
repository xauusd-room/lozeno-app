<template>
  <header class="header">
    <div class="header-inner page-container">
      <!-- Logo 标志 -->
      <router-link to="/" class="logo" aria-label="LOZENO 首页">
        <span class="logo-icon">L</span>
        <span class="logo-text">LOZENO</span>
      </router-link>

      <!-- 搜索栏区域 -->
      <div class="search-wrap">
        <form class="search" id="searchForm" @submit.prevent role="search">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m16 16 4 4"/></svg>
          <input
            id="searchInput"
            v-model="searchKeyword"
            @input="handleSearch"
            type="search"
            placeholder="搜索 EA / 插件..."
            autocomplete="off"
            aria-label="搜索 EA 或插件"
          />
          <span class="search-key">/</span>
        </form>
        <div class="search-results" :class="{ show: searchResults.length > 0 }">
          <a v-for="(item, index) in searchResults" :key="index" :href="item.url">{{ item.name }}</a>
        </div>
      </div>

      <!-- 导航链接（完整恢复：首页、EA排名、插件、活动） -->

<nav class="nav" aria-label="主导航">
  <router-link to="/">
    <svg viewBox="0 0 24 24"><path d="m3 10 9-7 9 7"/><path d="M5 9v12h14V9M9 21v-7h6v7"/></svg>
    <span>首页</span>
  </router-link>
  <router-link to="/market">
    <svg viewBox="0 0 24 24"><path d="M3 3v18h18"/><path d="m7 14 4-4 4 3 6-7"/></svg>
    <span>行情</span>
  </router-link>
  <router-link to="/ranking">
    <svg viewBox="0 0 24 24"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H3v2a5 5 0 0 0 5 5M17 6h4v2a5 5 0 0 1-5 5"/></svg>
    <span>EA排名</span>
  </router-link>
  <router-link to="/plugins">
    <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
    <span>插件</span>
  </router-link>
  <router-link to="/events">
    <svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="13" rx="2"/><path d="M12 8v13M3 12h18M12 8H7a3 3 0 1 1 3-3c0 2 2 3 2 3Zm0 0h5a3 3 0 1 0-3-3c0 2-2 3-2 3Z"/></svg>
    <span>活动</span>
  </router-link>
</nav>


      <!-- 登录注册按钮 -->
      <div class="actions">
        <a class="btn login" href="#login">登录</a>
        <a class="btn register" href="#register">注册</a>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref } from 'vue'

const searchKeyword = ref('')
const searchResults = ref([])
const items = [
  { name: 'EA排名', url: '/ranking', keywords: 'EA 自动交易 机器人 排名 策略' },
  { name: '插件', url: '/plugins', keywords: '插件 工具 扩展 指标' },
  { name: '活动', url: '/events', keywords: '活动 优惠 公告' },
  { name: '首页', url: '/', keywords: '首页 LOZENO' }
]

const handleSearch = () => {
  const query = searchKeyword.value.trim().toLowerCase()
  if (!query) {
    searchResults.value = []
    return
  }
  searchResults.value = items.filter(i => (i.name + ' ' + i.keywords).toLowerCase().includes(query))
}
</script>

<style scoped>
.header { position: sticky; top: 0; z-index: 1000; width: 100%; background: var(--主页面背景色, #0b0d12); border-bottom: 0; backdrop-filter: blur(8px); height: 74px; isolation: isolate; }
.header::after { content: ""; position: absolute; bottom: 0; left: 0; width: 100%; height: 1px; background: linear-gradient(90deg, transparent 0%, rgba(49,91,255,0.015) 15%, rgba(49,91,255,0.06) 28%, rgba(49,91,255,0.2) 38%, rgba(49,91,255,0.55) 46%, var(--主色调蓝色, #315bff) 50%, rgba(49,91,255,0.55) 54%, rgba(49,91,255,0.2) 62%, rgba(49,91,255,0.06) 72%, rgba(49,91,255,0.015) 85%, transparent 100%); pointer-events: none; }
.header-inner {height: 73px;  display: flex;  align-items: center;}
.logo { display: flex; align-items: center; gap: 10px; color: var(--主要文字颜色, #fff); text-decoration: none; white-space: nowrap; }
.logo-icon { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; background: var(--主色调蓝色, #315bff); border-radius: 8px; color: #fff; font-size: 20px; font-weight: 800; box-shadow: 0 0 12px var(--主色发光特效, rgba(49,91,255,0.2)); }
.logo-text { font-size: var(--logo标志字号, 21px); font-weight: 800; letter-spacing: .5px; }
.search-wrap { position: relative; width: 260px; margin-left: 24px; }
.search { height: 40px; width: 100%; display: flex; align-items: center; gap: 10px; padding: 0 12px; background: var(--输入框背景色, #1b1e26); border: 1px solid transparent; border-radius: 11px; transition: all .2s ease; }
.search:focus-within, .search:hover { border-color: var(--主色调蓝色, #315bff); box-shadow: 0 0 10px var(--主色发光特效, rgba(49,91,255,0.2)); }
.search svg { width: 18px; height: 18px; stroke: var(--次要灰色文字, #848e9c); fill: none; stroke-width: 2; flex-shrink: 0; }
.search input { width: 100%; border: 0; outline: 0; background: transparent; color: var(--主要文字颜色, #fff); font-size: 13px; }
.search input::placeholder { color: #5e6673; }
.search-key { color: var(--次要灰色文字, #848e9c); background: #2b2f3a; border-radius: 4px; padding: 2px 6px; font-size: 11px; font-weight: 600; }
.nav { display: flex; align-items: center; gap: 24px; margin-left: auto; margin-right: 24px; }
.nav a { display: flex; align-items: center; gap: 8px; padding: 10px 0; color: var(--次要灰色文字, #848e9c); font-size: 14px; font-weight: 600; text-decoration: none; transition: color .18s ease; }
.nav a svg { width: 18px; height: 18px; stroke: currentColor; fill: none; stroke-width: 2; flex-shrink: 0; }
.nav a.router-link-active, .nav a:hover { color: var(--主色调悬停色, #4169ff); }
.actions { display: flex; align-items: center; gap: 10px; }
.btn { height: 36px; padding: 0 16px; display: flex; align-items: center; justify-content: center; border-radius: 10px; font-size: 13px; font-weight: 600; text-decoration: none; transition: all .18s ease; }
.login { color: var(--主要文字颜色, #fff); border: 1px solid var(--边框线条颜色, #222630); background: transparent; }
.login:hover { color: var(--主色调悬停色, #4169ff); border-color: var(--主色调悬停色, #4169ff); }
.register { color: #fff; background: var(--主色调蓝色, #315bff); border-color: var(--主色调蓝色, #315bff); box-shadow: 0 4px 12px var(--主色发光特效, rgba(49,91,255,0.2)); }
.register:hover { background: var(--主色调悬停色, #4169ff); border-color: var(--主色调悬停色, #4169ff); transform: translateY(-1px); }
.search-results { display: none; position: absolute; top: 46px; left: 0; right: 0; padding: 6px; background: var(--表面卡片背景色, #141722); border: 1px solid var(--边框线条颜色, #222630); border-radius: 10px; box-shadow: 0 12px 30px rgba(0,0,0,.6); z-index: 20; }
.search-results.show { display: block; }
.search-results a { display: block; padding: 10px; border-radius: 6px; color: #c3cada; font-size: 13px; text-decoration: none; }
.search-results a:hover { color: #fff; background: var(--主色调蓝色, #315bff); }
</style>